# SaaS Rule Validator 3.0.x

By: Hari Patel and Christian Cairney

[TOC]

## Background

The previous IdentityNow Rule Validator was a Ruby-based tool that, while powerful, still suffered from a few limitations:

- **Ruby-based** - The Ruby-based runtime was easily portable and easy to run, but it wasn't easy for the field to consume and use; customers often are not are not familiar or comfortable with the installation and execution of Ruby, and the idea of getting things from Ruby gems is a bit awkward.  
- **File Naming Check** - The previous rule validator didn't check for our file-naming standards.  We need to make sure that the file name matches the rule’s name, with proper error handling.
- **Level of Check** - The previous rule validator checked against all errors and warnings, and reported all positive test results.  We’d like to be able to control the severity of the errors and warnings with a command-line parameter.
- **Multiple Line Validation** - The previous rule validator checked line-by-line which made looking for code that spans multiple lines impossible. 
- **No Distinction for Cloud-/Connector-Executed Rules** - With the recent release of connector rule import/export APIs, the SaaS Rule Validator now needs to handle specific messaging based on rule type. Cloud-executed rules have different disallowed fragments than connector-executed ones, and moreover, the API-based validation for connector-executed rules now takes precedence over the Rule Validator's results -- the validator needs to appropriately reject any connector-executed rules and redirect those to the productized API for validation.

To address these limitations, the SailPoint SaaS Rule Validator has been migrated to a Java runtime and includes enhanced results reporting as well as a more dynamic configuration of phrases or code fragments to monitor -- a simple addition/removal of an entry in the embedded config file allows us to quickly and easily update the validator for new fragments.

## Important Changes

The two major changes that rule writers should be aware of with respect to the validator are:

- New BeanShell Linter, validate syntax of the BeanShell code and object usage.
- Command line usage has changed slightly, please ensure the documentation is read and understood.
- Connector-executed rules will always throw an error; these rules are meant to be validated by the Engineering-provided Rule Management Service API.
- The following code fragments will throw a warning since they will soon be deprecated; they will still be allowed for existing rules as a review exception for a period of time, but any new rules using these constructs will be returned to the submitter, who will be asked to re-write the rule using the [IDN Rule Utility](https://sailpoint.atlassian.net/wiki/spaces/~205828486/pages/1331069443/Using+IDNRuleUtil+as+a+Wrapper+for+Common+Rule+Operations) helper methods instead:
  - context.
  - .getObjectById()
  - .getObjectByName()
  - .getObject()
  - .search()
  - .countObjects()

### Pre-Requisites

The only requirement for this tool to run is that the user must have Java JDK 11.0 or later.

### Installation

To use the Rule Validator locally, decompress the  "`sailpoint-saas-rule-validator-{version}-distribution.zip`" package into a folder on your workstation.  The `sp-rv` command executes the java package, and has been designed to be run from a path so can be executed anywhere from your file system.

###### Linux and MacOS considerations

Under Linux and MacOS ensure the `sp-rv` script has execute privileges, by executing the `chmod` command on the `sp-rv` script:

```
chmod +x sp-rv
```


### Usage

The Rule Validator has the following command line options:

| Switch name                                         | Description                                                  |
| --------------------------------------------------- | ------------------------------------------------------------ |
| --file{path or filename}<br />-f {path or filename} | Validate a file or directory                                 |
| --recursive<br />-r                                 | If a path is used for the --file (-f) switch, then it will also check it's sub directories.<br />If used with conjuction with the --watch (-w) switch, it will also monitor all subdirectories for changes. |
| --watch  {path}<br />-w {path}                      | Watch a directory for changes and automatically validate any files which have changed. |
| --lib {path}<br />-l {path}                         | Specify an additional path which contains JAR files to lint against |
| --verbose<br />-v                                   | Verbose output                                               |
| --noWarnings<br />-nw                               | Ignore all warnings (Not recommended when Listing)           |
| -logging<br />-l                                    | Set logging to Append, New or None.                          |

#### Validate

To run the validator with standard reporting, simply invoke the following:

```
sp-rv --file {path or file name}
```

or

```
sp-rv -f {path or file name}
```

This will automatically validate all XML files in the path or a spexific file name.

To automatically include all nested sub-directories in the validation run, simply provide the `--recursive` flag:

```
sp-rv --file "C:/Users/hari.patel/Desktop/rule-validator-test-rules" --recursive
```

or

```
sp-rv -f "C:/Users/hari.patel/Desktop/rule-validator-test-rules" -r
```

*Note:* If you provide a specific file name, then the `--recursive` flag parameter is ignored; the recursive evaluation will only be conducted if the filePath parameter is null or a directory.

#### Watch

To continually watch a folder for changes use:

```
sp-rv --watch {path}
```

or

```
sp-rv -w {path}
```

This will automatically validate all XML files within the path specification.  The path must always be a directory and not a file.

To automatically include all nested sub-directories in the validation run, simply provide the `--recursive` flag:

```
sp-rv --watch "C:/Users/hari.patel/Desktop/rule-validator-test-rules" --recursive
```

or

```
sp-rv -w "C:/Users/hari.patel/Desktop/rule-validator-test-rules" -r
```

**NB**. Please note that to exit watch mode press `CTRL+C`.

### bsh-lib folder

The Rule Validator uses the bsh-lib folder to lint against any API's which are used in the BeanShell rules.  If additional JAR libraries are needed then these can be added to the bsh-lib folder, please note however the bsh-lib folder is discovered from two paths

- The `bsh-lib` is initially loaded from the path where the validator JAR file is.
- A `bsh-lib` folder is attempted to be discovered in the current path where the `sp-rv` command is executed.

## How To...

#### Add variables to the BeanShell Linter

The Linter may attempt to reference variables which have been injected into the BeanShell environment by IDN but are not present in the Linter.  To add injected variables into a rule, add a signature to the XML document Rule node.  The Signature node describes the variable being injected, below is an example of a “Department” attribute bing  injected:

```xml
<Rule language="beanshell" name="company - rule_type - name">
  <Signature returnType="Object">
    <Inputs>
      <Argument name="department" type="java.lang.String">
        <Description>
          Identity attribute "department"
        </Description>
      </Argument>
    </Inputs>
  </Signature>
  ....
```

Generic rules may need additional objects adding to the Signature.  The next example shows that "identity" of type "sailpoint.object.Identity" is injected into the BeanShell script for linting:

```xml
<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE Rule PUBLIC "sailpoint.dtd" "sailpoint.dtd">
<Rule name="Test" >
  <Description>Designed to generate mail for active directory. </Description>
  <Signature returnType="Object">
  <Inputs>
    <Argument name="identity" type="sailpoint.object.Identity">
      <Description>
        Identity object type pushed into this rule... note the "type" attribute is set
        to "sailpoint.object.Identity", if not type is specified the Linter will "assume"
        this is of type "string".
        </Description>
    </Argument>
  </Inputs> 
  </Signature>
  <Source><![CDATA[
	log.debug("Identity name: " + identity.getName());
]]></Source>
</Rule>
```

#### Add an additional JAR file to lint against

On occasion BeanShell rules may need to reference JAR libraries which are not shipped with the Linter.  This will throw errors in the Rule Validator when attempting to validate a script.  To add an additional JAR to the linter so it can be resolved add the required JAR file into the bsh-jar folder which is shipped with the Validator deployment archive.  The bsh-jar folder can exist in two places:

1. The folder where the validator binaries are stored, will have a bsh-jar folder, it should already contains some library files which either stub some IDN Classes or other common used JAR files.  These libraries will be available globally when executing the Rule Validator.
2. An additional bsh-jar file can be added in the folder that the rule validator is executed in, this allows  custom JAR files to be used only form the folder and not globally.

### Known Limitations

- Variables may need to be injected into the XML Signature to ensure warnings of missing variable declarations.
- Generic types cannot be resolved with this release, only base types.
